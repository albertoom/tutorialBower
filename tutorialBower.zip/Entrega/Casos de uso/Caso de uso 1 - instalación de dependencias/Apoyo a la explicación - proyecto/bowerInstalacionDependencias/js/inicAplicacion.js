function manejaLoad() {
	var pulsame = document.getElementById('pulsame');
	pulsame.addEventListener('click', cambiaColor, false);
}