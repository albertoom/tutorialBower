function cambiaColor() {
	/*var hola = document.getElementById('hola');
	hola.className = "pulsado";*/
	$("#hola").css("color", "red");
}